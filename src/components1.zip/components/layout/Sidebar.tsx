import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, Map, TrendingUp, Satellite, Thermometer, 
  History, AlertTriangle, BarChart3, Database, Network,
  ChevronLeft, ChevronRight, Globe
} from 'lucide-react';
import clsx from 'clsx';

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

const navItems = [
  { path: '/dashboard', label: 'Overview', icon: LayoutDashboard, end: true },
  { path: '/dashboard/track', label: 'Track Prediction', icon: Map },
  { path: '/dashboard/intensity', label: 'Intensity Forecast', icon: TrendingUp },
  { path: '/dashboard/satellite', label: 'Satellite Intelligence', icon: Satellite },
  { path: '/dashboard/environment', label: 'Environmental Conditions', icon: Thermometer },
  { path: '/dashboard/historical', label: 'Historical Analysis', icon: History },
  { path: '/dashboard/risk', label: 'Risk Assessment', icon: AlertTriangle },
  { path: '/dashboard/models', label: 'Model Performance', icon: BarChart3 },
  { path: '/dashboard/data-sources', label: 'Data Sources', icon: Database },
  { path: '/dashboard/architecture', label: 'System Architecture', icon: Network },
];

export const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle }) => {
  return (
    <div className={clsx(
      "flex flex-col bg-gray-900 border-r border-slate-700 transition-all duration-300",
      isCollapsed ? "w-[72px]" : "w-[280px]"
    )}>
      <div className="flex items-center justify-between h-16 px-4 border-b border-slate-700">
        <NavLink to="/" className="flex items-center gap-3 overflow-hidden hover:opacity-80 transition-opacity">
          <Globe className="w-8 h-8 text-cyan-400 shrink-0" />
          {!isCollapsed && <span className="font-bold text-slate-100 whitespace-nowrap">CYCLONE AI</span>}
        </NavLink>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-2">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                end={item.end}
                className={({ isActive }) => clsx(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors group",
                  isActive 
                    ? "bg-cyan-500/15 border-l-2 border-cyan-400 text-cyan-400 font-medium" 
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
                )}
                title={isCollapsed ? item.label : undefined}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                {!isCollapsed && <span className="whitespace-nowrap">{item.label}</span>}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-4 border-t border-slate-700">
        <button 
          onClick={onToggle}
          className="flex items-center justify-center w-full p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};
