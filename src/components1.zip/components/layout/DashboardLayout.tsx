import React, { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { useOperationalData } from '../../hooks/useOperationalData';

const pageTitles: Record<string, string> = {
  '/dashboard': 'System Overview',
  '/dashboard/overview': 'System Overview',
  '/dashboard/track': 'Track Prediction',
  '/dashboard/intensity': 'Intensity Forecast',
  '/dashboard/satellite': 'Satellite Intelligence',
  '/dashboard/environment': 'Environmental Conditions',
  '/dashboard/environmental': 'Environmental Conditions',
  '/dashboard/historical': 'Historical Analysis',
  '/dashboard/history': 'Historical Analysis',
  '/dashboard/risk': 'GIS Risk Assessment',
  '/dashboard/models': 'Model Performance',
  '/dashboard/performance': 'Model Performance',
  '/dashboard/data-sources': 'Data Sources',
  '/dashboard/data': 'Data Sources',
  '/dashboard/architecture': 'System Architecture',
};

export const DashboardLayout: React.FC = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();
  const { isLive, lastFetched, refresh } = useOperationalData();
  
  const title = pageTitles[location.pathname] || 'Cyclone Intelligence Platform';

  return (
    <div className="flex h-screen overflow-hidden bg-[#0a0f1e] text-slate-100">
      <Sidebar isCollapsed={isCollapsed} onToggle={() => setIsCollapsed(!isCollapsed)} />
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar 
          title={title} 
          lastUpdated={lastFetched ? new Date(lastFetched).toLocaleTimeString() : undefined} 
          isLive={isLive} 
          onRefresh={refresh}
        />
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
