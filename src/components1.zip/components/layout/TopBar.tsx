import React from 'react';
import { Bell, RefreshCw, User } from 'lucide-react';
import clsx from 'clsx';

interface TopBarProps {
  title: string;
  lastUpdated?: string;
  isLive?: boolean;
  onRefresh?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ title, lastUpdated, isLive = false, onRefresh }) => {
  return (
    <header className="h-16 flex items-center justify-between px-6 bg-gray-900/80 backdrop-blur border-b border-slate-700">
      <div className="flex items-center">
        <h1 className="text-xl font-semibold text-slate-100">{title}</h1>
      </div>
      
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-4 text-sm text-slate-400">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              {isLive && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
              <span className={clsx("relative inline-flex rounded-full h-3 w-3", isLive ? "bg-emerald-500" : "bg-amber-500")}></span>
            </span>
            <span className="font-medium text-slate-300">{isLive ? 'LIVE' : 'DEMO DATA'}</span>
          </div>
          
          {lastUpdated && (
            <div className="hidden md:block border-l border-slate-700 pl-4">
              Last updated: {lastUpdated}
            </div>
          )}
        </div>

        <div className="flex items-center gap-4 border-l border-slate-700 pl-4">
          <button onClick={onRefresh} className="p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-full transition-colors" title="Refresh Data">
            <RefreshCw className="w-5 h-5" />
          </button>
          <button className="relative p-2 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-full transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-cyan-500 rounded-full border border-gray-900"></span>
          </button>
          <button className="flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 border border-slate-700 text-slate-300 hover:border-cyan-400 transition-colors">
            <User className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
