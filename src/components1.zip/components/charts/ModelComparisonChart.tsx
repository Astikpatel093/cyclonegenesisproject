import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

interface ModelComparisonChartProps {
  models: { name: string; mae: number; error24h: number; error48h: number; error72h: number }[];
  height?: number;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-800 border border-slate-600 p-3 rounded shadow-lg z-50">
        <p className="text-slate-200 text-sm font-bold mb-1">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={`item-${index}`} style={{ color: entry.color }} className="text-sm">
            {entry.name}: {entry.value} km
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export const ModelComparisonChart: React.FC<ModelComparisonChartProps> = ({
  models,
  height = 400,
}) => {
  const data = [
    {
      metric: 'MAE',
      Baseline: models.find(m => m.name === 'Baseline')?.mae || 0,
      XGBoost: models.find(m => m.name === 'XGBoost')?.mae || 0,
      'Deep Learning': models.find(m => m.name === 'Deep Learning')?.mae || 0,
    },
    {
      metric: '24h Error',
      Baseline: models.find(m => m.name === 'Baseline')?.error24h || 0,
      XGBoost: models.find(m => m.name === 'XGBoost')?.error24h || 0,
      'Deep Learning': models.find(m => m.name === 'Deep Learning')?.error24h || 0,
    },
    {
      metric: '48h Error',
      Baseline: models.find(m => m.name === 'Baseline')?.error48h || 0,
      XGBoost: models.find(m => m.name === 'XGBoost')?.error48h || 0,
      'Deep Learning': models.find(m => m.name === 'Deep Learning')?.error48h || 0,
    },
    {
      metric: '72h Error',
      Baseline: models.find(m => m.name === 'Baseline')?.error72h || 0,
      XGBoost: models.find(m => m.name === 'XGBoost')?.error72h || 0,
      'Deep Learning': models.find(m => m.name === 'Deep Learning')?.error72h || 0,
    },
  ];

  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
          <XAxis dataKey="metric" stroke="#94a3b8" />
          <YAxis stroke="#94a3b8" label={{ value: 'Error (km)', angle: -90, position: 'insideLeft', fill: '#94a3b8', dy: 40 }} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#334155', opacity: 0.4 }} />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          <Bar dataKey="Baseline" fill="#64748b" radius={[4, 4, 0, 0]} />
          <Bar dataKey="XGBoost" fill="#f59e0b" radius={[4, 4, 0, 0]} />
          <Bar dataKey="Deep Learning" fill="#06b6d4" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
