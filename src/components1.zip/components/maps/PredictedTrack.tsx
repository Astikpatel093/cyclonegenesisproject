import React from 'react';
import { Polyline, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import type { ForecastPoint } from '../../types/prediction';

interface PredictedTrackProps {
  forecastPoints: ForecastPoint[];
  visibleHorizon?: number; // show points up to this hour
}

export const PredictedTrack: React.FC<PredictedTrackProps> = ({
  forecastPoints,
  visibleHorizon = 120,
}) => {
  const visiblePoints = forecastPoints.filter(p => p.forecastHour <= visibleHorizon);
  if (!visiblePoints || visiblePoints.length === 0) return null;

  const positions: [number, number][] = visiblePoints.map(p => [p.lat, p.lon]);

  return (
    <>
      <Polyline
        positions={positions}
        color="#06b6d4"
        weight={2}
        dashArray="10, 10"
      />
      {visiblePoints.map((point, idx) => {
        const icon = L.divIcon({
          className: 'bg-transparent border-0',
          html: `<div class="w-6 h-6 bg-cyan-500 transform rotate-45 border-2 border-slate-900 shadow-md flex items-center justify-center">
                  <span class="transform -rotate-45 text-[10px] text-white font-bold">${point.forecastHour}</span>
                 </div>`,
          iconSize: [24, 24],
          iconAnchor: [12, 12],
        });

        return (
          <Marker key={`pred-pt-${idx}`} position={[point.lat, point.lon]} icon={icon}>
            <Popup className="dark-leaflet-popup">
              <div className="text-sm">
                <p className="font-bold text-cyan-400">+{point.forecastHour}h Forecast</p>
                <p>Position: {point.lat.toFixed(2)}°N, {point.lon.toFixed(2)}°E</p>
                <p>Wind: {point.predictedWind} knots</p>
                <p>Pressure: {point.predictedPressure} hPa</p>
                {point.uncertainty && <p>Uncertainty: {point.uncertainty} km</p>}
              </div>
            </Popup>
          </Marker>
        );
      })}
    </>
  );
};
