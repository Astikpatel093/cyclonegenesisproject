import React from 'react';
import { MapContainer, TileLayer, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { twMerge } from 'tailwind-merge';

interface CycloneMapProps {
  center?: [number, number]; // default [15, 85] - Bay of Bengal
  zoom?: number; // default 5
  className?: string;
  children?: React.ReactNode;
  showLayerControl?: boolean;
}

export const CycloneMap: React.FC<CycloneMapProps> = ({
  center = [15, 85],
  zoom = 5,
  className,
  children,
  showLayerControl: _showLayerControl = false,
}) => {
  return (
    <div className={twMerge('w-full h-full rounded-xl overflow-hidden relative', className)}>
      <MapContainer
        center={center}
        zoom={zoom}
        minZoom={3}
        maxZoom={18}
        zoomControl={false}
        className="w-full h-full z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://carto.com/attributions">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        <ZoomControl position="bottomright" />
        {children}
      </MapContainer>
    </div>
  );
};
