import React from 'react';
import { GeoJSON } from 'react-leaflet';
import type { DistrictRisk } from '../../types/risk';
import { getRiskLevelColor } from '../../utils/colors';

interface DistrictBoundariesProps {
  districts?: DistrictRisk[];
  data?: DistrictRisk[];
  onDistrictClick?: (district: DistrictRisk) => void;
  showRiskColors?: boolean;
}

export const DistrictBoundaries: React.FC<DistrictBoundariesProps> = ({
  districts,
  data,
  onDistrictClick,
  showRiskColors = true,
}) => {
  const items = districts || data || [];
  if (!items || items.length === 0) return null;

  return (
    <>
      {items.map((districtRisk, idx) => {
        const geom = districtRisk.district?.geometry || (districtRisk as any).geometry;
        if (!geom) return null;

        const geoJsonFeature = {
          type: 'Feature' as const,
          properties: {
            name: districtRisk.district?.name || (districtRisk as any).districtName,
            state: districtRisk.district?.state || (districtRisk as any).state,
            riskLevel: districtRisk.riskLevel,
          },
          geometry: geom,
        };

        return (
          <GeoJSON
            key={`district-${idx}-${districtRisk.district?.id || idx}`}
            data={geoJsonFeature as any}
            style={{
              fillColor: showRiskColors ? getRiskLevelColor(districtRisk.riskLevel) : 'transparent',
              fillOpacity: 0.35,
              color: '#334155',
              weight: 2,
            }}
            eventHandlers={{
              click: () => onDistrictClick && onDistrictClick(districtRisk),
              mouseover: (e) => {
                const layer = e.target;
                layer.setStyle({ fillOpacity: 0.65, weight: 3 });
              },
              mouseout: (e) => {
                const layer = e.target;
                layer.setStyle({ fillOpacity: 0.35, weight: 2 });
              },
            }}
          />
        );
      })}
    </>
  );
};
